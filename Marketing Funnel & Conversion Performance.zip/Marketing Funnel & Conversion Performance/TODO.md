# Task 3 – Marketing Funnel & Conversion Performance Analysis (2026)

## Plan steps
- [x] Create project skeleton (README, requirements, src/, notebooks/, data/, reports/)
- [x] Generate synthetic funnel dataset and save to `data/funnel_data.csv`
- [x] Implement funnel metrics computation in `src/funnel_analysis.py`
- [x] Build analysis notebook/script (script used for reliable execution)
- [x] Generate interactive Plotly dashboard HTML in `reports/dashboard/funnel_dashboard.html`
- [x] Write insights summary in `reports/README_insights.md`
- [x] Finalize root `README.md` with run instructions and deliverables
- [x] Run notebook/script to ensure dashboard is generated


