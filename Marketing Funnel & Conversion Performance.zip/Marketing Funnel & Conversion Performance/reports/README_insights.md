# Funnel Analysis Insights & Recommendations

## Summary
- Traffic → Lead conversion: 5.2%
- Lead → Customer conversion: 16.4%
- Visitor → Customer conversion: 0.9%

## Drop-off bottleneck
- Biggest drop-off: Visitor → Lead
  - Dropped count: 47390
  - Drop-off rate: 94.8%

## Actionable recommendations
- Primary bottleneck is Traffic → Lead. Improve landing page relevance (message match), add stronger lead magnets, and reduce friction in the signup/lead form.
- Scale budget toward high-performing channels (e.g., 'Email' with the highest overall conversion) and audit spend/levers on low-performing channels like 'Social Ads'.
- Replicate creative/targeting from top campaigns: Winback_Offer (Email), Newsletter_Warmup (Email), Partner_Program (Referral). Use A/B tests on CTAs and offer strength for campaigns with weaker Lead→Customer conversion.
- Set KPI targets: increase Traffic→Lead (currently 5.2%) and Lead→Customer (currently 16.4%) with experiments sized to impact the funnel stages producing the largest drop-offs.

## Where to look next
- Compare by campaign and channel in the dashboard
- Run A/B tests specifically targeting the largest drop-off stage
