import os
import sys
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go

# Ensure project root is on sys.path when running from notebooks/
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.funnel_analysis import (
    compute_funnel_metrics,
    compute_dropoff_table,
    funnel_counts_by_dimension,
    add_time_columns,
    compute_channel_campaign_insights,
    generate_basic_recommendations,
)



def main():
    os.makedirs('data', exist_ok=True)
    os.makedirs('reports/dashboard', exist_ok=True)
    os.makedirs('reports', exist_ok=True)

    df = pd.read_csv('data/funnel_data.csv')
    df['is_lead'] = df['is_lead'].astype(bool)
    df['is_customer'] = df['is_customer'].astype(bool)
    df['event_date'] = pd.to_datetime(df['event_date'])

    overall = compute_funnel_metrics(df)
    dropoff = compute_dropoff_table(df)

    channel_perf = funnel_counts_by_dimension(df, 'channel').sort_values(
        'overall_visitor_to_customer_conversion_rate', ascending=False
    )
    channel_campaign = compute_channel_campaign_insights(df)

    df_time = add_time_columns(df, 'event_date')
    month_perf = funnel_counts_by_dimension(df_time, 'year_month').sort_values('year_month')

    # Funnel chart
    fig_funnel = go.Figure(
        go.Funnel(
            y=['Visitor', 'Lead', 'Customer'],
            x=[overall['n_visitors'], overall['n_leads'], overall['n_customers']],
            textinfo='value+percent initial',
        )
    )
    fig_funnel.update_layout(title='Overall Funnel: Visitors → Leads → Customers')

    # Drop-off chart
    fig_drop = px.bar(
        dropoff,
        x='count_dropped',
        y='from_stage',
        orientation='h',
        color='to_stage',
        title='Drop-off Counts Between Funnel Stages',
        text=dropoff['rate_dropped'].map(lambda v: f"{v:.1%}" if pd.notna(v) else 'NA'),
    )
    fig_drop.update_layout(yaxis_title='From stage', xaxis_title='Dropped count')

    # Channel conversion
    fig_channel = px.bar(
        channel_perf,
        x='channel',
        y='overall_visitor_to_customer_conversion_rate',
        title='Overall Visitor → Customer Conversion Rate by Channel',
        text=channel_perf['overall_visitor_to_customer_conversion_rate'].map(lambda v: f"{v:.1%}"),
    )
    fig_channel.update_layout(
        xaxis_title='Channel',
        yaxis_title='Conversion rate',
        xaxis_tickangle=-35,
    )

    # Campaign top performers
    top_camps = channel_campaign.head(15).copy()
    top_camps['label'] = top_camps['campaign'] + ' (' + top_camps['channel'] + ')'
    fig_campaign = px.bar(
        top_camps,
        x='overall_visitor_to_customer_conversion_rate',
        y='label',
        orientation='h',
        title='Top Campaigns by Visitor → Customer Conversion',
        text=top_camps['overall_visitor_to_customer_conversion_rate'].map(lambda v: f"{v:.1%}"),
    )
    fig_campaign.update_layout(xaxis_title='Conversion rate', yaxis_title='Campaign')

    # Monthly trend
    fig_month = px.line(
        month_perf,
        x='year_month',
        y='overall_visitor_to_customer_conversion_rate',
        markers=True,
        title='Monthly Trend: Visitor → Customer Conversion Rate',
    )
    fig_month.update_layout(xaxis_title='Month', yaxis_title='Conversion rate')

    # Write dashboard HTML
    html_parts = [
        fig_funnel.to_html(full_html=False, include_plotlyjs='cdn'),
        fig_drop.to_html(full_html=False, include_plotlyjs='cdn'),
        fig_channel.to_html(full_html=False, include_plotlyjs='cdn'),
        fig_campaign.to_html(full_html=False, include_plotlyjs='cdn'),
        fig_month.to_html(full_html=False, include_plotlyjs='cdn'),
    ]

    dashboard_html = "\n".join(html_parts)
    out_path = 'reports/dashboard/funnel_dashboard.html'
    with open(out_path, 'w', encoding='utf-8') as f:
        f.write(
            """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Funnel Dashboard</title>
<style>body{font-family:Arial,Helvetica,sans-serif;margin:20px;} .plotly-graph-div{margin:10px 0;}</style>
</head>
<body>
<h1>Marketing Funnel & Conversion Performance</h1>
<p>Interactive dashboard generated from Task 3 analysis.</p>
"""
        )
        f.write(dashboard_html)
        f.write("\n</body></html>")

    # Recommendations
    recommendations = generate_basic_recommendations(
        overall=overall,
        dropoff=dropoff,
        channel_perf=channel_perf,
        top_campaigns=channel_campaign,
    )

    insights_path = 'reports/README_insights.md'
    best_drop = dropoff.sort_values('count_dropped', ascending=False).iloc[0]

    with open(insights_path, 'w', encoding='utf-8') as f:
        f.write('# Funnel Analysis Insights & Recommendations\n\n')
        f.write('## Summary\n')
        f.write(f"- Traffic → Lead conversion: {overall['traffic_to_lead_conversion_rate']:.1%}\n")
        f.write(f"- Lead → Customer conversion: {overall['lead_to_customer_conversion_rate']:.1%}\n")
        f.write(f"- Visitor → Customer conversion: {overall['overall_visitor_to_customer_conversion_rate']:.1%}\n")
        f.write('\n## Drop-off bottleneck\n')
        f.write(
            f"- Biggest drop-off: {str(best_drop['from_stage']).title()} → {str(best_drop['to_stage']).title()}\n"
        )
        f.write(f"  - Dropped count: {int(best_drop['count_dropped'])}\n")
        f.write(f"  - Drop-off rate: {best_drop['rate_dropped']:.1%}\n")
        f.write('\n## Actionable recommendations\n')
        for rec in recommendations:
            f.write(f"- {rec}\n")
        f.write('\n## Where to look next\n')
        f.write('- Compare by campaign and channel in the dashboard\n')
        f.write('- Run A/B tests specifically targeting the largest drop-off stage\n')

    print('Wrote dashboard ->', out_path)
    print('Wrote insights ->', insights_path)


if __name__ == '__main__':
    main()

