# Marketing Funnel & Conversion Performance Analysis (Task 3 – 2026)

This project analyzes a marketing funnel from **visitors → leads → customers**.
It computes:
- Traffic → Lead conversion rate
- Lead → Customer conversion rate
- Drop-off counts and drop-off rates at each stage
- Performance breakdown by **channel**, **campaign**, and **time (month/week)**

It also produces an interactive HTML dashboard and a short insights/recommendations summary.

## What’s included
- `data/funnel_data.csv` — generated synthetic funnel dataset (visitors with lead/customer conversion flags)
- `src/synthetic_data.py` — generates the dataset
- `src/funnel_analysis.py` — funnel metric utilities
- `notebooks/task3_funnel_analysis.ipynb` — analysis + dashboard generation
- `reports/dashboard/funnel_dashboard.html` — interactive dashboard
- `reports/README_insights.md` — actionable recommendations

## Setup
```bash
pip install -r requirements.txt
```

## Generate dataset
```bash
python src/synthetic_data.py
```

## Run analysis + generate dashboard
```bash
# from project root
py -m pip install -r requirements.txt
py src/synthetic_data.py
py notebooks/task3_funnel_analysis.py
```

## Dashboard
Open:
- `reports/dashboard/funnel_dashboard.html`


## Notes
The dataset is synthetic (because no dataset was provided). If you later add a real dataset CSV, update the schema in the notebook (required columns described in `src/funnel_analysis.py`).

