import pandas as pd
import numpy as np

STAGES = ["visitor", "lead", "customer"]


def _validate_columns(df: pd.DataFrame) -> pd.DataFrame:
    required = {
        "event_date",
        "channel",
        "campaign",
        "visitor_id",
        "is_lead",
        "is_customer",
    }
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")

    # Basic typing
    df = df.copy()
    df["event_date"] = pd.to_datetime(df["event_date"], errors="coerce")
    if df["event_date"].isna().any():
        raise ValueError("Some rows have invalid event_date values.")

    for c in ["is_lead", "is_customer"]:
        if not pd.api.types.is_bool_dtype(df[c]):
            # allow 0/1
            df[c] = df[c].astype(int).astype(bool)

    df["channel"] = df["channel"].astype(str)
    df["campaign"] = df["campaign"].astype(str)
    df["visitor_id"] = df["visitor_id"].astype(str)
    return df


def compute_funnel_metrics(df: pd.DataFrame) -> dict:
    """Compute overall funnel metrics.

    Expected schema:
      - event_date: datetime-like
      - visitor_id: unique id per visitor record
      - is_lead: boolean
      - is_customer: boolean
    """
    df = _validate_columns(df)

    n_visitors = len(df)
    n_leads = int(df["is_lead"].sum())
    n_customers = int(df["is_customer"].sum())

    traffic_to_lead = n_leads / n_visitors if n_visitors else np.nan
    lead_to_customer = n_customers / n_leads if n_leads else np.nan
    overall_conversion = n_customers / n_visitors if n_visitors else np.nan

    return {
        "n_visitors": n_visitors,
        "n_leads": n_leads,
        "n_customers": n_customers,
        "traffic_to_lead_conversion_rate": traffic_to_lead,
        "lead_to_customer_conversion_rate": lead_to_customer,
        "overall_visitor_to_customer_conversion_rate": overall_conversion,
    }


def compute_dropoff_table(df: pd.DataFrame) -> pd.DataFrame:
    """Return drop-off counts and rates between stages."""
    df = _validate_columns(df)

    n_visitors = len(df)
    n_leads = int(df["is_lead"].sum())
    n_customers = int(df["is_customer"].sum())

    # Drop-offs
    drop_vis_to_lead = n_visitors - n_leads
    drop_lead_to_cust = n_leads - n_customers

    rows = [
        {
            "from_stage": "visitor",
            "to_stage": "lead",
            "count_dropped": drop_vis_to_lead,
            "rate_dropped": drop_vis_to_lead / n_visitors if n_visitors else np.nan,
        },
        {
            "from_stage": "lead",
            "to_stage": "customer",
            "count_dropped": drop_lead_to_cust,
            "rate_dropped": drop_lead_to_cust / n_leads if n_leads else np.nan,
        },
    ]
    return pd.DataFrame(rows)


def funnel_counts_by_dimension(df: pd.DataFrame, dimension: str) -> pd.DataFrame:
    """Counts at each stage grouped by a dimension (channel/campaign/month/etc)."""
    df = _validate_columns(df)
    if dimension not in df.columns:
        raise ValueError(f"Dimension '{dimension}' not found in dataframe")

    grouped = df.groupby(dimension, dropna=False).agg(
        n_visitors=("visitor_id", "count"),
        n_leads=("is_lead", "sum"),
        n_customers=("is_customer", "sum"),
    )
    grouped["traffic_to_lead_conversion_rate"] = grouped["n_leads"] / grouped["n_visitors"]
    grouped["lead_to_customer_conversion_rate"] = grouped["n_customers"] / grouped["n_leads"]
    grouped["overall_visitor_to_customer_conversion_rate"] = grouped["n_customers"] / grouped["n_visitors"]
    grouped = grouped.reset_index()
    return grouped


def add_time_columns(df: pd.DataFrame, date_col: str = "event_date") -> pd.DataFrame:
    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")
    df["year_month"] = df[date_col].dt.to_period("M").astype(str)
    df["year_week"] = df[date_col].dt.to_period("W").astype(str)
    return df


def compute_channel_campaign_insights(df: pd.DataFrame) -> pd.DataFrame:
    """Convenience helper: compute conversions by channel & campaign."""
    df = _validate_columns(df)

    grouped = (
        df.groupby(["channel", "campaign"], dropna=False)
        .agg(
            n_visitors=("visitor_id", "count"),
            n_leads=("is_lead", "sum"),
            n_customers=("is_customer", "sum"),
        )
        .reset_index()
    )
    grouped["traffic_to_lead_conversion_rate"] = grouped["n_leads"] / grouped["n_visitors"]
    grouped["lead_to_customer_conversion_rate"] = grouped["n_customers"] / grouped["n_leads"]
    grouped["overall_visitor_to_customer_conversion_rate"] = grouped["n_customers"] / grouped["n_visitors"]

    # Rank by overall conversion
    grouped = grouped.sort_values("overall_visitor_to_customer_conversion_rate", ascending=False)
    return grouped


def generate_basic_recommendations(overall: dict, dropoff: pd.DataFrame, channel_perf: pd.DataFrame, top_campaigns: pd.DataFrame) -> list:
    """Return a small list of actionable recommendations."""
    recs = []

    # Determine biggest drop-off bottleneck
    bottleneck = dropoff.sort_values("count_dropped", ascending=False).iloc[0]
    if bottleneck["from_stage"] == "visitor":
        recs.append(
            "Primary bottleneck is Traffic → Lead. Improve landing page relevance (message match), add stronger lead magnets, and reduce friction in the signup/lead form."
        )
    else:
        recs.append(
            "Primary bottleneck is Lead → Customer. Improve qualification + nurture (email/retargeting), ensure lead scoring, and tighten handoff between marketing and sales."
        )

    # Channel-focused
    if not channel_perf.empty:
        best = channel_perf.sort_values("overall_visitor_to_customer_conversion_rate", ascending=False).head(1).iloc[0]
        worst = channel_perf.sort_values("overall_visitor_to_customer_conversion_rate", ascending=True).head(1).iloc[0]
        recs.append(
            f"Scale budget toward high-performing channels (e.g., '{best['channel']}' with the highest overall conversion) and audit spend/levers on low-performing channels like '{worst['channel']}'."
        )

    # Campaigns
    if not top_campaigns.empty:
        top = top_campaigns.head(3)
        campaigns = ", ".join([f"{row['campaign']} ({row['channel']})" for _, row in top.iterrows()])
        recs.append(
            f"Replicate creative/targeting from top campaigns: {campaigns}. Use A/B tests on CTAs and offer strength for campaigns with weaker Lead→Customer conversion."
        )

    # Conversion framing
    recs.append(
        f"Set KPI targets: increase Traffic→Lead (currently {overall['traffic_to_lead_conversion_rate']:.1%}) and Lead→Customer (currently {overall['lead_to_customer_conversion_rate']:.1%}) with experiments sized to impact the funnel stages producing the largest drop-offs."
    )

    return recs

