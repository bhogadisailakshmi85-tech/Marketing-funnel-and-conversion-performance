import numpy as np
import pandas as pd


def generate_synthetic_funnel_data(
    n_visitors: int = 50000,
    start_date: str = "2026-01-01",
    end_date: str = "2026-12-31",
    seed: int = 42,
) -> pd.DataFrame:
    """Generate a realistic-ish synthetic funnel dataset.

    Schema:
      - event_date: date of the visitor record
      - channel: acquisition channel
      - campaign: marketing campaign within channel
      - visitor_id: unique identifier
      - is_lead: whether visitor became a lead
      - is_customer: whether lead became a customer

    Note: for simplicity each visitor has one row; conversion flags are correlated.
    """
    rng = np.random.default_rng(seed)

    channels = ["Organic Search", "Paid Search", "Social Ads", "Email", "Referral"]
    campaigns_by_channel = {
        "Organic Search": ["SEO_Brand", "SEO_NonBrand"],
        "Paid Search": ["Search_Brand", "Search_Competitor", "Search_Generic"],
        "Social Ads": ["IG_LeadGen", "FB_Retargeting", "TikTok_Test"],
        "Email": ["Newsletter_Warmup", "Winback_Offer"],
        "Referral": ["Partner_Program", "Community_Referrals"],
    }

    # Generate dates uniformly across range
    date_range = pd.date_range(start_date, end_date, freq="D")
    event_dates = rng.choice(date_range, size=n_visitors)

    # Channel mix with some seasonality
    channel_base_weights = np.array([0.28, 0.30, 0.18, 0.10, 0.14], dtype=float)
    month = pd.to_datetime(event_dates).month
    season = 1 + 0.08 * np.sin((month - 1) / 12 * 2 * np.pi)  # mild seasonality

    # Apply seasonality multiplier per visitor, then normalize per row
    weights = np.tile(channel_base_weights, (n_visitors, 1)) * season.values[:, None]
    weights = weights / weights.sum(axis=1, keepdims=True)

    channel_idx = np.array([rng.choice(len(channels), p=weights[i]) for i in range(n_visitors)])

    channel = np.array(channels)[channel_idx]

    # Campaign selection per channel
    campaign = np.empty(n_visitors, dtype=object)
    for i, ch in enumerate(channel):
        campaign_list = campaigns_by_channel[ch]
        # Slight bias to retargeting later in the year
        if ch == "Social Ads" and (pd.to_datetime(event_dates[i]).month >= 8):
            campaign_list = campaign_list + ["FB_Retargeting"]
        campaign[i] = rng.choice(campaign_list)

    # Stage conversion probabilities by channel/campaign, plus noise
    # Base traffic->lead by channel
    lead_rate_by_channel = {
        "Organic Search": 0.045,
        "Paid Search": 0.055,
        "Social Ads": 0.035,
        "Email": 0.070,
        "Referral": 0.060,
    }
    # Campaign multipliers
    campaign_multiplier = {
        # Organic
        "SEO_Brand": 1.10,
        "SEO_NonBrand": 0.95,
        # Paid
        "Search_Brand": 1.15,
        "Search_Competitor": 0.98,
        "Search_Generic": 0.90,
        # Social
        "IG_LeadGen": 0.92,
        "FB_Retargeting": 1.20,
        "TikTok_Test": 0.75,
        # Email
        "Newsletter_Warmup": 1.05,
        "Winback_Offer": 1.25,
        # Referral
        "Partner_Program": 1.12,
        "Community_Referrals": 0.98,
    }

    base_lead = np.array([lead_rate_by_channel[c] for c in channel])
    mult = np.array([campaign_multiplier[c] for c in campaign])

    # Add mild noise and cap
    lead_prob = np.clip(base_lead * mult * rng.normal(1.0, 0.12, size=n_visitors), 0.005, 0.25)

    is_lead = rng.random(n_visitors) < lead_prob

    # Lead->customer conditional; depends on channel/campaign and whether it's a lead
    # Base lead->customer by channel
    cust_rate_by_channel = {
        "Organic Search": 0.13,
        "Paid Search": 0.16,
        "Social Ads": 0.10,
        "Email": 0.22,
        "Referral": 0.20,
    }
    cust_mult = {
        "SEO_Brand": 1.05,
        "SEO_NonBrand": 0.92,
        "Search_Brand": 1.08,
        "Search_Competitor": 1.00,
        "Search_Generic": 0.88,
        "IG_LeadGen": 0.90,
        "FB_Retargeting": 1.10,
        "TikTok_Test": 0.75,
        "Newsletter_Warmup": 1.00,
        "Winback_Offer": 1.18,
        "Partner_Program": 1.05,
        "Community_Referrals": 0.95,
    }

    cust_base = np.array([cust_rate_by_channel[c] for c in channel])
    cust_m = np.array([cust_mult[c] for c in campaign])
    cust_prob = np.clip(cust_base * cust_m * rng.normal(1.0, 0.10, size=n_visitors), 0.01, 0.60)

    is_customer = np.zeros(n_visitors, dtype=bool)
    customer_when_lead = is_lead
    is_customer[customer_when_lead] = rng.random(customer_when_lead.sum()) < cust_prob[customer_when_lead]

    df = pd.DataFrame(
        {
            "event_date": pd.to_datetime(event_dates).date.astype(str),
            "channel": channel,
            "campaign": campaign,
            "visitor_id": [f"v_{i}" for i in range(n_visitors)],
            "is_lead": is_lead,
            "is_customer": is_customer,
        }
    )
    return df


def main():
    df = generate_synthetic_funnel_data()
    out_path = "data/funnel_data.csv"
    import os

    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Saved synthetic dataset -> {out_path} (rows={len(df)})")


if __name__ == "__main__":
    main()

